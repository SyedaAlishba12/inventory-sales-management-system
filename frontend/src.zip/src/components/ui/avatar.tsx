"use client"; 
 
import * as AvatarPrimitive from "@radix-ui/react-avatar"; 
import type { ComponentProps } from "react"; 
 
import { cn } from "@/utils/cn"; 
 
export function Avatar({ className, ...props }: ComponentProps<typeof AvatarPrimitive.Root>) { 
  return <AvatarPrimitive.Root className={cn("relative flex size-9 shrink-0 overflow-hidden rounded-full", className)} {...props} />; 
} 
 
export function AvatarImage({ className, ...props }: ComponentProps<typeof AvatarPrimitive.Image>) { 
  return <AvatarPrimitive.Image className={cn("aspect-square size-full object-cover", className)} {...props} />; 
} 
 
export function AvatarFallback({ className, ...props }: ComponentProps<typeof AvatarPrimitive.Fallback>) { 
  return ( 
    <AvatarPrimitive.Fallback 
      className={cn("flex size-full items-center justify-center rounded-full bg-[#78A394]/15 text-xs font-semibold text-[#0F4C5C]", className)} 
      {...props} 
    /> 
  ); 
} 