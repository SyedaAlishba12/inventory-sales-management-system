"use client"; 
 
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu"; 
import { Check, ChevronRight, Circle } from "lucide-react"; 
import type { ComponentProps } from "react"; 
 
import { cn } from "@/utils/cn"; 
 
export const DropdownMenu = DropdownMenuPrimitive.Root; 
export const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger; 
export const DropdownMenuGroup = DropdownMenuPrimitive.Group; 
export const DropdownMenuPortal = DropdownMenuPrimitive.Portal; 
export const DropdownMenuSub = DropdownMenuPrimitive.Sub; 
export const DropdownMenuRadioGroup = DropdownMenuPrimitive.RadioGroup; 
 
export function DropdownMenuContent({ 
  className, 
  sideOffset = 6, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.Content>) { 
  return ( 
    <DropdownMenuPrimitive.Portal> 
      <DropdownMenuPrimitive.Content 
        sideOffset={sideOffset} 
        className={cn( 
          "z-50 min-w-44 overflow-hidden rounded-lg border border-[#D7E0E3] bg-card p-1 text-card-foreground shadow-xl", 
          className, 
        )} 
        {...props} 
      /> 
    </DropdownMenuPrimitive.Portal> 
  ); 
} 
 
export function DropdownMenuItem({ 
  className, 
  inset, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.Item> & { inset?: boolean }) { 
  return ( 
    <DropdownMenuPrimitive.Item 
      className={cn( 
        "relative flex cursor-default select-none items-center gap-2 rounded-md px-2 py-2 text-sm text-[#0F4C5C] outline-none transition-colors focus:bg-[#EAF0F2] data-[disabled]:pointer-events-none data-[disabled]:opacity-50", 
        inset && "pl-8", 
        className, 
      )} 
      {...props} 
    /> 
  ); 
} 
 
export function DropdownMenuCheckboxItem({ 
  className, 
  children, 
  checked, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.CheckboxItem>) { 
  return ( 
    <DropdownMenuPrimitive.CheckboxItem 
      checked={checked} 
      className={cn( 
        "relative flex cursor-default select-none items-center rounded-md py-2 pr-2 pl-8 text-sm text-[#0F4C5C] outline-none focus:bg-[#EAF0F2] data-[disabled]:pointer-events-none data-[disabled]:opacity-50", 
        className, 
      )} 
      {...props} 
    > 
      <span className="absolute left-2 flex size-4 items-center justify-center"> 
        <DropdownMenuPrimitive.ItemIndicator> 
          <Check className="size-4" /> 
        </DropdownMenuPrimitive.ItemIndicator> 
      </span> 
      {children} 
    </DropdownMenuPrimitive.CheckboxItem> 
  ); 
} 
 
export function DropdownMenuRadioItem({ 
  className, 
  children, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.RadioItem>) { 
  return ( 
    <DropdownMenuPrimitive.RadioItem 
      className={cn( 
        "relative flex cursor-default select-none items-center rounded-md py-2 pr-2 pl-8 text-sm text-[#0F4C5C] outline-none focus:bg-[#EAF0F2] data-[disabled]:pointer-events-none data-[disabled]:opacity-50", 
        className, 
      )} 
      {...props} 
    > 
      <span className="absolute left-2 flex size-4 items-center justify-center"> 
        <DropdownMenuPrimitive.ItemIndicator> 
          <Circle className="size-2 fill-current" /> 
        </DropdownMenuPrimitive.ItemIndicator> 
      </span> 
      {children} 
    </DropdownMenuPrimitive.RadioItem> 
  ); 
} 
 
export function DropdownMenuLabel({ 
  className, 
  inset, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.Label> & { inset?: boolean }) { 
  return ( 
    <DropdownMenuPrimitive.Label 
      className={cn("px-2 py-1.5 text-xs font-semibold text-[#7A8B91]", inset && "pl-8", className)} 
      {...props} 
    /> 
  ); 
} 
 
export function DropdownMenuSeparator({ className, ...props }: ComponentProps<typeof DropdownMenuPrimitive.Separator>) { 
  return <DropdownMenuPrimitive.Separator className={cn("-mx-1 my-1 h-px bg-[#D7E0E3]", className)} {...props} />; 
} 
 
export function DropdownMenuShortcut({ className, ...props }: ComponentProps<"span">) { 
  return <span className={cn("ml-auto text-xs tracking-widest text-[#7A8B91]", className)} {...props} />; 
} 
 
export function DropdownMenuSubTrigger({ 
  className, 
  inset, 
  children, 
  ...props 
}: ComponentProps<typeof DropdownMenuPrimitive.SubTrigger> & { inset?: boolean }) { 
  return ( 
    <DropdownMenuPrimitive.SubTrigger 
      className={cn( 
        "flex cursor-default select-none items-center rounded-md px-2 py-2 text-sm text-[#0F4C5C] outline-none focus:bg-[#EAF0F2] data-[state=open]:bg-[#EAF0F2]", 
        inset && "pl-8", 
        className, 
      )} 
      {...props} 
    > 
      {children} 
      <ChevronRight className="ml-auto size-4" /> 
    </DropdownMenuPrimitive.SubTrigger> 
  ); 
} 
 
export function DropdownMenuSubContent({ className, ...props }: ComponentProps<typeof DropdownMenuPrimitive.SubContent>) { 
  return ( 
    <DropdownMenuPrimitive.SubContent 
      className={cn("z-50 min-w-40 rounded-lg border border-[#D7E0E3] bg-card p-1 text-card-foreground shadow-xl", className)} 
      {...props} 
    /> 
  ); 
} 