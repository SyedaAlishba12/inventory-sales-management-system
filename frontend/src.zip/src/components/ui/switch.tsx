"use client"; 
 
import * as SwitchPrimitive from "@radix-ui/react-switch"; 
import type { ComponentProps } from "react"; 
 
import { cn } from "@/utils/cn"; 
 
export function Switch({ className, ...props }: ComponentProps<typeof SwitchPrimitive.Root>) { 
  return ( 
    <SwitchPrimitive.Root 
      className={cn( 
        "peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent bg-[#D7E0E3] outline-none transition-colors focus-visible:ring-2 focus-visible:ring-[#78A394] focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-[#0F4C5C]", 
        className, 
      )} 
      {...props} 
    > 
      <SwitchPrimitive.Thumb className="pointer-events-none block size-5 rounded-full bg-card shadow-md transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0" /> 
    </SwitchPrimitive.Root> 
  ); 
} 